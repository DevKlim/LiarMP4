// background.js - Handles network requests

const BACKEND_URL = "http://localhost:8005";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'INGEST_LINK') {
        ingestLink(message.link)
            .then(data => sendResponse({success: true, data: data}))
            .catch(err => sendResponse({success: false, error: err.toString()}));
        return true; // Indicates async response
    }
    
    if (message.type === 'SAVE_MANUAL') {
        saveManualLabel(message.payload)
            .then(data => sendResponse({success: true, data: data}))
            .catch(err => sendResponse({success: false, error: err.toString()}));
        return true;
    }
});

async function ingestLink(link) {
    try {
        const response = await fetch(`${BACKEND_URL}/extension/ingest`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ link: link })
        });
        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    } catch (error) {
        console.error("Ingest failed:", error);
        throw error;
    }
}

async function saveManualLabel(payload) {
    try {
        const response = await fetch(`${BACKEND_URL}/extension/save_manual`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!response.ok) throw new Error(`Server error: ${response.status}`);
        return await response.json();
    } catch (error) {
        console.error("Manual Save failed:", error);
        throw error;
    }
}